import React, { useState, useEffect } from "react";
import CanvasJSReact from "@canvasjs/react-charts";

const BarGraph = () => {
  const CanvasJSChart = CanvasJSReact.CanvasJSChart;

  const [options, setOptions] = useState({
    animationEnabled: true,
    theme: "light2",
    title: {
      text: "Engagement Data",
    },
    axisX: {
      type: "dateTime",
      title: "Time",
      valueFormatString: "hh:mm:ss TT",
      crosshair: {
        enabled: true,
        snapToDataPoint: true,
      },
    },
    axisY: {
      title: "Engagement Score",
      minimum: 1,
      maximum: 10,
    },
    data: [
      {
        type: "line",
        xValueFormatString: "hh:mm:ss TT",
        yValueFormatString: "##0.##",
        dataPoints: [],
      },
    ],
  });

  const [historicalData, setHistoricalData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://127.0.0.1:8000/engagement");
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const data = await response.json();
        const { time, engagement_score } = data;

        // Update historicalData with new data point
        const newDataPoint = { x: new Date(time), y: engagement_score };
        setHistoricalData((prevData) => [...prevData, newDataPoint]);

        // Update options.data[0].dataPoints with historicalData
        setOptions({
          ...options,
          data: [
            {
              ...options.data[0],
              dataPoints: [...historicalData, newDataPoint],
            },
          ],
        });
      } catch (error) {
        console.error(
          "There was a problem with the fetch operation:",
          error.message
        );
      }
    };

    // Make the initial request immediately
    // fetchData();

    // Set up an interval for subsequent requests
    const timer = setInterval(() => {
      fetchData();
    }, 10000); // Adjust the interval as needed

    // Cleanup the interval when the component unmounts
    return () => {
      clearInterval(timer);
    };
  }, [options, historicalData]);

  return (
    <div
      className="app"
      style={{
        display: "flex",
        paddingLeft: "20px",
        justifyContent: "center",
        alignItems: "center",
        height: "100vh",
      }}
    >
      <div className="row">
        <div className="mixed-chart">
          <CanvasJSChart options={options} />
        </div>
      </div>
    </div>
  );
};

export default BarGraph;
