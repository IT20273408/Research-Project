import React, { useState, useContext, useEffect } from "react";
import {
  Button,
  TextField,
  Grid,
  Typography,
  Container,
  Paper,
  Fab,
} from "@material-ui/core";
import { CopyToClipboard } from "react-copy-to-clipboard";
import { Assignment, Phone, PhoneDisabled } from "@material-ui/icons";
import KeyboardVoiceIcon from "@mui/icons-material/KeyboardVoice";
import MicOffIcon from "@mui/icons-material/MicOff";
import LaptopIcon from "@mui/icons-material/Laptop";
import BarChartIcon from "@mui/icons-material/BarChart";
import ArticleIcon from "@mui/icons-material/Article";
import ContentPasteIcon from "@mui/icons-material/ContentPaste";
import CameraAltIcon from "@mui/icons-material/CameraAlt";
import NoPhotographyIcon from "@mui/icons-material/NoPhotography";
import { makeStyles } from "@material-ui/core/styles";
import axios from "axios";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import { SocketContext } from "../Context";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
} from "@material-ui/core";
import BarGraph from "./graph";
import { Box, Card } from "@mui/material";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexDirection: "column",
  },
  gridContainer: {
    width: "100%",
    [theme.breakpoints.down("xs")]: {
      flexDirection: "column",
    },
  },
  container: {
    width: "600px",
    margin: "35px 0",
    padding: 0,
    [theme.breakpoints.down("xs")]: {
      width: "80%",
    },
  },
  margin: {
    marginTop: 20,
  },
  padding: {
    padding: 20,
  },
  paper: {
    padding: "10px 20px",
    border: "2px solid black",
  },
}));

const Sidebar = ({ children }) => {
  const {
    me,
    callAccepted,
    name,
    setName,
    callEnded,
    leaveCall,
    callUser,
    setIsCameraOn,
    setIsMicMuted,
    isCameraOn,
    isMicMuted,
  } = useContext(SocketContext);
  const [idToCall, setIdToCall] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDialogPCOpen, setIsDialogPCOpen] = useState(false);
  const classes = useStyles();

  const userRole = localStorage.getItem("USER_ROLE");

  const dialogStyle = {
    width: "80%",
    height: "80%",
    maxHeight: "none",
    maxWidth: "none",
  };

  const callMuteFun = () => {
    setIsMicMuted(!isMicMuted);
  };

  const callCameraFun = () => {
    setIsCameraOn(!isCameraOn);
  };

  const handleOpenDialog = () => {
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
  };

  const handleOpenPCDialog = () => {
    setIsDialogPCOpen(true);
  };

  const handleClosePCDialog = () => {
    setIsDialogPCOpen(false);
  };

  const [questions, setQuestions] = useState([]);
  const [newQuestion, setNewQuestion] = useState("");
  const [answers, setAnswers] = useState([]);
  const [marks, setMarks] = useState([]);

  const handleQuestionChange = (event) => {
    setNewQuestion(event.target.value);
  };

  const handleAddQuestion = () => {
    if (newQuestion.trim() !== "") {
      const updatedQuestions = [...questions, { question_text: newQuestion }];
      setQuestions(updatedQuestions);
      setNewQuestion("");
    }
  };

  const fetchQuestions = async () => {
    try {
      const res = await axios.get("http://localhost:8000/get_questions");
      if (res?.data?.status_code === 200) {
        setQuestions(res?.data?.questions);
        setAnswers(
          res?.data?.questions.map((ques) => ({
            question: ques?.question_text,
            answer: "",
          }))
        );
      } else {
        alert("Something went wrong! Please try again.");
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    let fetchInterval;

    if (userRole === "student" && questions.length === 0) {
      // fetchQuestions();
      fetchInterval = setInterval(fetchQuestions, 10000);
    }

    return () => {
      clearInterval(fetchInterval);
    };
  }, [questions, userRole]);

  const handlePostQuestions = async () => {
    try {
      const res = await axios.post(
        "http://localhost:8000/add_questions",
        questions
      );

      if (res?.data?.status_code === 200) {
        alert("Questions successfully added. ");
        setQuestions([]);
        setIsDialogPCOpen(false);
      } else {
        alert("Something went wrong! Please try again.");
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleClearQuestions = async () => {
    try {
      const res = await axios.post("http://localhost:8000/add_questions", []);

      if (res?.data?.status_code === 200) {
        alert("Questions successfully cleared. ");
        setQuestions([]);
        setIsDialogPCOpen(false);
      } else {
        alert("Something went wrong! Please try again.");
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleAddAnswers = (index, answer) => {
    const updatedAnswers = [...answers];
    updatedAnswers[index].answer = answer;
    setAnswers(updatedAnswers);
  };

  const submitAnswers = async () => {
    try {
      const res = await axios.post(
        "http://localhost:8000/predict-student-marks",
        answers
      );

      if (res?.data?.status_code === 200) {
        setMarks(res?.data?.data);
      } else {
        alert("Something went wrong! Please try again.");
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <Container className={classes.container}>
      <Paper elevation={10} className={classes.paper}>
        <form className={classes.root} noValidate autoComplete="off">
          {callAccepted && !callEnded ? (
            <Grid container className={classes.gridContainer}>
              <Fab
                aria-label="add"
                onClick={callMuteFun}
                style={{
                  backgroundColor: "#b0aeae",
                  marginRight: "11px",
                  marginLeft: "11px",
                }}
              >
                {!isMicMuted ? <KeyboardVoiceIcon /> : <MicOffIcon />}
              </Fab>
              <Fab
                aria-label="add"
                onClick={callCameraFun}
                style={{
                  backgroundColor: "#b0aeae",
                  marginRight: "11px",
                  marginLeft: "11px",
                }}
              >
                {isCameraOn ? <CameraAltIcon /> : <NoPhotographyIcon />}
              </Fab>
              <Fab
                aria-label="add"
                style={{
                  backgroundColor: "#b0aeae",
                  marginRight: "11px",
                  marginLeft: "11px",
                }}
              >
                <ArticleIcon />
              </Fab>
              <Fab
                aria-label="add"
                onClick={leaveCall}
                style={{
                  backgroundColor: "#D10000",
                  marginRight: "11px",
                  marginLeft: "11px",
                }}
              >
                <PhoneDisabled />
              </Fab>
              <Fab
                aria-label="add"
                style={{
                  backgroundColor: "#b0aeae",
                  marginRight: "11px",
                  marginLeft: "11px",
                }}
                onClick={handleOpenPCDialog}
              >
                <LaptopIcon />
              </Fab>
              <Dialog
                open={isDialogPCOpen}
                onClose={handleClosePCDialog}
                maxWidth="lg"
                PaperProps={{ style: dialogStyle }}
              >
                <DialogTitle style={{ fontSize: 20, fontWeight: "700" }}>
                  Exam Center
                </DialogTitle>
                {userRole === "lecturer" ? (
                  <DialogContent>
                    <Card variant="outlined">
                      <Typography
                        style={{
                          display: "flex",
                          justifyContent: "center",
                          fontSize: 20,
                          fontWeight: "700",
                          paddingTop: "20px",
                        }}
                      >
                        Add Your Questions
                      </Typography>

                      <Box>
                        <div>
                          <Box style={{ padding: "20px" }}>
                            <TextField
                              id="outlined-textarea"
                              label="Enter a question"
                              multiline
                              placeholder="Enter a question"
                              value={newQuestion}
                              onChange={handleQuestionChange}
                              fullWidth
                              style={{ marginBottom: "20px" }}
                            />
                            <center>
                              <div>
                                <Button
                                  variant="outlined"
                                  onClick={handleAddQuestion}
                                >
                                  Add Question
                                </Button>
                              </div>
                            </center>
                          </Box>
                          <Box style={{ padding: "20px" }}>
                            <Typography
                              style={{
                                display: "flex",
                                justifyContent: "center",
                                fontSize: 20,
                                fontWeight: 800,
                              }}
                            >
                              Questions to Post
                            </Typography>
                            <ul style={{ padding: "30px" }}>
                              {questions?.map((question, index) => (
                                <li
                                  key={index}
                                  style={{
                                    fontSize: "20px",
                                    fontWeight: 500,
                                    padding: "4px",
                                  }}
                                >
                                  {question.question_text}
                                </li>
                              ))}
                            </ul>
                            <center>
                              <div>
                                <Button
                                  variant="outlined"
                                  onClick={handleClearQuestions}
                                  style={{ marginRight: "5px" }}
                                >
                                  Clear Questions
                                </Button>
                                <Button
                                  variant="outlined"
                                  onClick={handlePostQuestions}
                                >
                                  Post Questions
                                </Button>
                              </div>
                            </center>
                          </Box>
                        </div>
                      </Box>
                    </Card>
                  </DialogContent>
                ) : (
                  <DialogContent>
                    {marks?.length > 0 ? (
                      <Card variant="outlined">
                        <Typography
                          style={{
                            fontWeight: "600",
                            fontSize: "20px",
                            display: "flex",
                            justifyContent: "center",
                            padding: "10px",
                          }}
                        >
                          Your Quiz Marks
                        </Typography>
                        <TableContainer component={Paper}>
                          <Table
                            sx={{ minWidth: 650 }}
                            aria-label="simple table"
                          >
                            <TableHead>
                              <TableRow>
                                <TableCell sx={{ fontWeight: 800 }}>
                                  QNo
                                </TableCell>
                                <TableCell sx={{ fontWeight: 800 }}>
                                  Question
                                </TableCell>
                                <TableCell sx={{ fontWeight: 800 }}>
                                  Answer
                                </TableCell>
                                <TableCell sx={{ fontWeight: 800 }}>
                                  Marks
                                </TableCell>
                                <TableCell sx={{ fontWeight: 800 }}>
                                  Grade
                                </TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {marks?.map((marks, index) => (
                                <TableRow
                                  key={index}
                                  sx={{
                                    "&:last-child td, &:last-child th": {
                                      border: 0,
                                    },
                                  }}
                                >
                                  <TableCell component="th" scope="row">
                                    {index + 1}
                                  </TableCell>
                                  <TableCell>{marks.question}</TableCell>
                                  <TableCell>{marks.answer}</TableCell>
                                  <TableCell>{marks.mark}</TableCell>
                                  <TableCell>{marks.grade}</TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </TableContainer>
                      </Card>
                    ) : (
                      <Card variant="outlined">
                        <Typography
                          style={{
                            display: "flex",
                            justifyContent: "center",
                            fontSize: 20,
                            fontWeight: "700",
                            paddingTop: "20px",
                          }}
                        >
                          Your Questions
                        </Typography>
                        <Box>
                          <ol style={{ padding: "30px" }}>
                            {questions?.map((question, index) => (
                              <div key={index}>
                                <li
                                  style={{
                                    fontSize: "20px",
                                    fontWeight: 500,
                                    padding: "4px",
                                  }}
                                >
                                  {question.question_text}
                                </li>
                                <TextField
                                  id="outlined-textarea"
                                  label="Type your Anwer"
                                  multiline
                                  rows={2}
                                  placeholder="Type your Anwer"
                                  value={answers[index]?.answer}
                                  onChange={(e) =>
                                    handleAddAnswers(index, e.target.value)
                                  }
                                  fullWidth
                                  style={{ marginBottom: "20px" }}
                                  variant="outlined"
                                />
                              </div>
                            ))}
                          </ol>
                          <center>
                            <div>
                              <Button
                                variant="outlined"
                                onClick={submitAnswers}
                                style={{ marginBottom: "10px" }}
                              >
                                Submit
                              </Button>
                            </div>
                          </center>
                        </Box>
                      </Card>
                    )}
                  </DialogContent>
                )}
                <DialogActions>
                  <Button onClick={handleClosePCDialog} color="primary">
                    Close
                  </Button>
                </DialogActions>
              </Dialog>

              <Fab
                aria-label="add"
                onClick={handleOpenDialog}
                style={{
                  backgroundColor: "#b0aeae",
                  marginRight: "11px",
                  marginLeft: "11px",
                }}
              >
                <BarChartIcon />
              </Fab>

              <Dialog
                open={isDialogOpen}
                onClose={handleCloseDialog}
                maxWidth="lg"
                PaperProps={{ style: dialogStyle }}
              >
                <DialogTitle>{"Student Engagement Level Info"}</DialogTitle>
                <DialogContent>
                  <DialogContentText />
                </DialogContent>
                <DialogContent>
                  <BarGraph />
                </DialogContent>
                <DialogActions>
                  <Button onClick={handleCloseDialog} color="primary">
                    Close
                  </Button>
                </DialogActions>
              </Dialog>

              <Fab
                aria-label="add"
                style={{
                  backgroundColor: "#b0aeae",
                  marginRight: "11px",
                  marginLeft: "11px",
                }}
              >
                <ContentPasteIcon />
              </Fab>
            </Grid>
          ) : (
            <Grid container className={classes.gridContainer}>
              {userRole === "lecturer" ? (
                <Grid item xs={12} md={6} className={classes.padding}>
                  <Typography gutterBottom variant="h6">
                    Meeting Info
                  </Typography>
                  <TextField
                    label="Meeting Title"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    fullWidth
                  />
                  <CopyToClipboard text={me} className={classes.margin}>
                    <Button
                      variant="contained"
                      color="primary"
                      fullWidth
                      startIcon={<Assignment fontSize="large" />}
                    >
                      Copy Your ID
                    </Button>
                  </CopyToClipboard>
                </Grid>
              ) : (
                <>
                  <Grid item xs={12} md={6} className={classes.padding}>
                    <Typography gutterBottom variant="h6">
                      Join the Meeting
                    </Typography>
                    <TextField
                      label="Student Name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      fullWidth
                    />
                  </Grid>
                  <Grid item xs={12} md={6} className={classes.padding}>
                    <TextField
                      label="Meeting ID"
                      value={idToCall}
                      onChange={(e) => setIdToCall(e.target.value)}
                      fullWidth
                    />
                    <Button
                      variant="contained"
                      color="primary"
                      startIcon={<Phone fontSize="large" />}
                      fullWidth
                      onClick={() => callUser(idToCall)}
                      className={classes.margin}
                    >
                      Join
                    </Button>
                  </Grid>
                </>
              )}
            </Grid>
          )}
        </form>
        {children}
      </Paper>
    </Container>
  );
};

export default Sidebar;
