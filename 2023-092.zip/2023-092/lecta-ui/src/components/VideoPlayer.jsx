import React, { useContext, useEffect, useState } from "react";
import { Grid, Typography, Paper, makeStyles } from "@material-ui/core";
import { SocketContext } from "../Context";
import axios from "axios";

const useStyles = makeStyles((theme) => ({
  video: {
    width: "550px",
    [theme.breakpoints.down("xs")]: {
      width: "300px",
    },
  },
  gridContainer: {
    justifyContent: "center",
    [theme.breakpoints.down("xs")]: {
      flexDirection: "column",
    },
  },
  paper: {
    padding: "10px",
    border: "2px solid black",
    margin: "10px",
  },
}));

const VideoPlayer = () => {
  const { name, callAccepted, myVideo, userVideo, callEnded, stream, call } =
    useContext(SocketContext);
  const classes = useStyles();

  const [engagementLevel, setEngagementLevel] = useState("");

  useEffect(() => {
    if (callAccepted && !callEnded) {
      const intervalId = setInterval(() => {
        sendImage();
      }, 10000); // 30 seconds in milliseconds

      // Clean up the interval when the component unmounts
      return () => {
        clearInterval(intervalId);
      };
    }
  }, [callAccepted, callEnded]);

  const captureImage = () => {
    const canvas = document.createElement("canvas");
    canvas.width = userVideo.current.videoWidth;
    canvas.height = userVideo.current.videoHeight;
    canvas.getContext("2d").drawImage(userVideo.current, 0, 0);
    return canvas.toDataURL("image/jpeg");
  };

  const dataURLtoFile = (dataurl, filename) => {
    let arr = dataurl.split(","),
      mime = arr[0].match(/:(.*?);/)[1],
      bstr = atob(arr[1]),
      n = bstr.length,
      u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  };

  const sendImage = async () => {
    const image = captureImage();
    const formData = new FormData();
    formData.append("file", dataURLtoFile(image, "captured.jpg"));

    try {
      const response = await axios.post(
        "http://127.0.0.1:8000/detect",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      const data = response.data;
      setEngagementLevel(data.engagement_score);

      const {
        body_position,
        engagement_level,
        engagement_score,
        face_expression,
        time,
      } = data;

      console.log(
        "engagementLevel 02: ",
        engagementLevel,
        body_position,
        engagement_level,
        face_expression
      );

      // Update historicalData with new data point
      const newDataPoint = { x: new Date(time), y: engagement_score };

      const storedHistoricalData =
      JSON.parse(localStorage.getItem("historicalData")) || [];

      const updatedData = [...storedHistoricalData, newDataPoint];

      // Update localStorage with the new data
      localStorage.setItem("historicalData", JSON.stringify(updatedData));

      console.log(data);
    } catch (error) {
      console.error("Error sending image to server:", error);
    }
  };

  return (
    <Grid container className={classes.gridContainer}>
      {stream && (
        <Paper className={classes.paper}>
          <Grid item xs={12} md={6}>
            <Typography variant="h5" gutterBottom>
              {name || "Name"}
            </Typography>
            <video
              playsInline
              muted
              ref={myVideo}
              autoPlay
              className={classes.video}
            />
          </Grid>
        </Paper>
      )}
      {callAccepted && !callEnded && (
        <Paper className={classes.paper}>
          <Grid item xs={12} md={6}>
            <Typography variant="h5" gutterBottom>
              {call.name || "Name"}
            </Typography>
            <video
              playsInline
              ref={userVideo}
              autoPlay
              className={classes.video}
            />
          </Grid>
        </Paper>
      )}
      {/* <button onClick={sendImage}>Button</button> */}
    </Grid>
  );
};

export default VideoPlayer;
