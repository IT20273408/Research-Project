import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from "react-router-dom";
import axios from 'axios';
import Webcam from 'react-webcam';

const AddNewUser = () => {
  const [newusername, setNewUsername] = useState('');
  const [newuserid, setNewUserId] = useState('');
  const [showCamera, setShowCamera] = useState(false);
  const [capMode, setCapMode] = useState(false);
  const [totalUsers, setTotalUsers] = useState(0); // State to store the total user count
  const [counter, setCounter] = useState(0);
  const webcamRef = useRef(null);
  const nav = useNavigate();


  useEffect(() => {
    // Fetch and update the total user count when the component mounts
    fetchTotalUsers();
  }, []);

  const fetchTotalUsers = async () => {
    try {
      const backendUrl = 'http://localhost:8000';
      const response = await axios.get(`${backendUrl}/total`);
      setTotalUsers(response.data.total);
    } catch (error) {
      console.error(error);
    }
  };

  const handleAddUser = async (e) => {
    e.preventDefault();


    try {
      const backendUrl = 'http://localhost:8000';
      const image = webcamRef.current.getScreenshot(); // Capture the image
      const formData = new FormData();
      const images = [];

      // Append the captured image and other data to FormData
      formData.append('newusername', newusername);
      formData.append('newuserid', parseInt(newuserid));
      formData.append('image', image);


      setCapMode(true);

      
      let count = 1;

      const cf = async() => {

        const image = webcamRef.current.getScreenshot(); // Capture the image

        console.log(count, image);

        formData.append('images[]', image);
        images.push(image);

        setCounter((prevCounter) => prevCounter + 1);

        count++;

        if(count > 50){
          clearInterval(captureFrames);

          const  response = await axios.post(`${backendUrl}/add`,  { newusername : newusername,newuserid : parseInt(newuserid), image: image, images: images 
          });

          alert(response.data.message);

          if(response.data.success === "true"){
              nav("/");
          }

          // Show the camera after adding the user
          setShowCamera(true);

          setCapMode(false);

          setCounter(0);

          // Update the total user count
          fetchTotalUsers();

        }
      }

      const captureFrames = setInterval(cf, 100);
     
    } catch (error) {
      console.error(error);
      setCapMode(false);
    }
  };

  const openCam = () => {
    setShowCamera(true);
  };

  const containerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
  };

  const formStyle = {
    width: '100%',
    maxWidth: '400px',
    padding: '20px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    textAlign: 'center',
    boxSizing: 'border-box'
  };

  const titleStyle = {
    marginBottom: '20px',
    fontSize: '24px',
  };

  const labelStyle = {
    marginBottom: '5px',
    fontSize: '16px',
    fontWeight: 'bold',
  };

  const inputStyle = {
    width: '100%',
    padding: '10px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    marginBottom: '10px',
    boxSizing: 'border-box'
  };

  const buttonStyle = {
    padding: '10px 20px',
    margin: '10px 0 0',
    borderColor:  capMode ? '#ccc' : '#343a40',
    color: 'white',
    borderRadius: '5px',
    cursor: capMode ? 'not-allowed' : 'pointer',
    backgroundColor: capMode ? '#ccc' : '#343a40',
  };

  const totalUsersStyle = {
    margin: '10px 0',
    fontSize: '16px',
    fontWeight: 'normal',
  };

  const videoStyle = {
    width: '100%'
  };

  const capturingStyle = {
    position: 'absolute',
    top: '8px',
    left: '8px',
    color: 'blue',
    fontSize: '30px',
    fontWeight: 'bold'
  };

  const holder = {
    position: 'relative'
  };

  return (
    <div style={containerStyle}>
      <div style={formStyle}>
        <h2 style={titleStyle}>Add New User</h2>
        <div>
          <label htmlFor="newusername" style={labelStyle}>
            Enter New User Name:
          </label>
          <input
            type="text"
            id="newusername"
            value={newusername}
            onChange={(e) => setNewUsername(e.target.value)}
            style={inputStyle}
            required
          />
        </div>
        <div>
          <label htmlFor="newuserid" style={labelStyle}>
            Enter New User ID:
          </label>
          <input
            type="number"
            id="newuserid"
            value={newuserid}
            onChange={(e) => setNewUserId(e.target.value)}
            style={inputStyle}
            required
          />
        </div>
        {!showCamera && (
          <button type="button" style={buttonStyle} onClick={openCam}>
            Open Cam
          </button>
        )}
        {showCamera && (
          <div style={holder}>
            <Webcam  style={videoStyle} ref={webcamRef} mirrored={true} audio={false}    screenshotFormat="image/jpeg" />
            {
              capMode &&
              <span style={capturingStyle} >Capturing: {counter}/50</span>
            }
            <button type="button" style={buttonStyle} onClick={handleAddUser} disabled={capMode}>
              {capMode ? 'Processing...' : 'Add User'}
            </button>
          </div>
        )}
        <h5 style={totalUsersStyle}>Total Users in Database: {totalUsers}</h5>
        <Link to={'/'}>Back to Home</Link>
      </div>
    </div>
  );
};

export default AddNewUser;
