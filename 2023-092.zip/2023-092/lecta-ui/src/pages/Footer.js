import React from "react";
import Calendar from "./Calendar"; // Import the Calendar component

const Footer = () => {
  const footerStyle = {
    backgroundColor: "#333",
    color: "white",
    padding: "20px",
    display: "flex", // Use flexbox to arrange sections from left to right
    justifyContent: "space-between", // Space sections evenly
    alignItems: "center", // Center vertically
  };

  const sectionStyle = {
    padding: "10px",
    textAlign: "left",
    display: "flex",
    flexDirection: "column",
    alignSelf: "flex-start", // Ensure the content stacks vertically
  };

  const headingStyle = {
    fontWeight: "bold",
    paddingBottom: "30px",
  };
  
  const linkStyle = {
    color: "white",
    textDecoration: "none",
    display: "block",
    margin: "5px 0",
    paddingBottom: "5px",
  };

  const copyrightStyle = {
    textAlign: "center",
    backgroundColor: "#333",
    color: "white",
    padding: "10px",
  };

  return (
    <div>
      <footer style={footerStyle}>
        <div style={sectionStyle}>
          <h3 style={headingStyle}>Social</h3>
          <a href="https://www.facebook.com" style={linkStyle}>
            Facebook
          </a>
          <a href="https://www.instagram.com" style={linkStyle}>
            Instagram
          </a>
        </div>

        <div style={sectionStyle}>
          <h3 style={headingStyle}>Contact</h3>
          <p style={linkStyle}>0777 111 111</p>
          <p style={linkStyle}>lecta@gmail.com</p>
          <p style={linkStyle}>69, Temple Avenue, Maradana, Colombo 10</p>
        </div>

        <div style={sectionStyle}>
          <h3 style={headingStyle}>Quick Links</h3>
          <a href="#" style={linkStyle}>
            Privacy Policy
          </a>
          <a href="#" style={linkStyle}>
            Terms & Conditions
          </a>
          <a href="#" style={linkStyle}>
            Contact Us
          </a>
        </div>
        <Calendar /> {/* Include the Calendar component here */}
      </footer>
      <hr/>
      <div style={copyrightStyle}>
        <p>&copy; 2023 Your Education Institution</p>
      </div>
    </div>
  );
};

export default Footer;
