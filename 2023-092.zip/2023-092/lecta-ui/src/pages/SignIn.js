import React, { useState } from "react";
// import { db } from "../server/firebase";
import "./style.css";

const Login = () => {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
    if (email === "Theeban" && password === "Theeban@123") {
      localStorage.setItem("USER_ROLE", "student");
      alert("You have successfully logged in as a student.");
    } else if (email === "admin" && password === "admin@123") {
      localStorage.setItem("USER_ROLE", "lecturer");
      alert("You have successfully logged in as a lecturer.");
    } else {
      alert("Invalid username or password.");
    }    
    // e.preventDefault();
    // try {
    //   const res = await db.auth().signInWithEmailAndPassword(email, password);
    //   console.log(res)
    //   // Successful login
    // } catch (error) {
    //   console.error("Login error:", error.message);
    // }
  };

  return (
    <div className="login-page">
      <div className="form">
        <form className="login-form" onSubmit={handleLogin}>
          <input type="text" placeholder="Username" value={email} onChange={(e) => setEmail(e.target.value)} />
          <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <button type="submit">login</button>
          <p className="message">Not registered? <a href="/signup">Create an account</a></p>
        </form>
      </div>
    </div>
  )
}

export default Login