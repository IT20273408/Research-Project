import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import Webcam from 'react-webcam';
import { Link } from "react-router-dom";

const TodayAttendance = () => {
  const [isTakingAttendance, setIsTakingAttendance] = useState(false);
  const webcamRef = useRef(null);
  const [todayData, setTodayData] = useState(null);
  const backendUrl = 'http://localhost:8000'; // Replace with your FastAPI server URL

  useEffect(() => {
    fetchTodayAttendance();
  }, []);
  
  const fetchTodayAttendance = async () => {
    try {
      const response = await axios.get(`${backendUrl}/todayAttendance`);
      setTodayData(response.data);
    } catch (error) {
      console.error(error);
    }
  };
  
  
  const handleTakeAttendance = async () => {
    setIsTakingAttendance(true);
  };

  const handleMarkAttendance = async () => {


    const frame = webcamRef.current.getScreenshot();

    const formData = new FormData();
    formData.append('image', frame);

    // Send the frame to your FastAPI server for face recognition
    const  response = await axios.post(`${backendUrl}/markAttendance`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data', // Set the appropriate content type
      },
    });

    alert(response.data.message);

    if(response.data.success === "true"){
      fetchTodayAttendance();
      setIsTakingAttendance(false);
    }

  };

  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
    minHeight: '100vh',
    background: '#f8f9fa',
  };

  const cardStyle = {
    backgroundColor: 'white',
    padding: '20px',
    borderRadius: '10px',
    boxShadow: '0px 2px 6px rgba(0, 0, 0, 0.1)',
    width: '80%',
    maxWidth: '500px',
  };

  const buttonStyle = {
    backgroundColor: isTakingAttendance ? '#ccc' : '#007bff',
    borderColor: isTakingAttendance ? '#ccc' : '#007bff',
    color: isTakingAttendance ? '#666' : 'white',
    padding: '10px 20px',
    margin: '10px 0',
    width: '100%',
    borderRadius: '5px',
    cursor: isTakingAttendance ? 'not-allowed' : 'pointer',
  };

  const tableStyle = {
    width: '100%',
    border: '1px solid #dee2e6',
    marginBottom: '1rem',
    borderRadius: '0.25rem',
    fontSize: '14px',
  };

  const videoStyle = {
    width: '100%'
  };

  
  const blackButtonStyle = {
    padding: '10px 20px',
    margin: '10px 0',
    backgroundColor: '#343a40',
    borderColor: '#343a40',
    color: 'white',
    borderRadius: '5px',
    cursor: 'pointer',
  };

  return (
    <div className="col" style={containerStyle}>
      <div style={cardStyle}>
        <h2>Attendance</h2>

        {
          !isTakingAttendance &&
          <button
            className="btn btn-primary"
            style={buttonStyle}
            onClick={handleTakeAttendance}
            disabled={isTakingAttendance}
          >
            {isTakingAttendance ? 'Taking Attendance...' : 'Take Attendance'}
          </button>
        }

        {
        isTakingAttendance &&

        <button type="button" style={blackButtonStyle} onClick={handleMarkAttendance}>
              Mark Attendance
        </button>
        }


        {isTakingAttendance && (
          <Webcam
            style={videoStyle}
            mirrored={true} 
            audio={false}
            ref={webcamRef}
            screenshotFormat="image/jpeg"
          />
        )}
        <table className="table table-bordered" style={tableStyle}>
          <thead>
            <tr>
              <th>S No</th>
              <th>Name</th>
              <th>ID</th>
              <th>Time</th>
            </tr>
          </thead>
          <tbody>
            {todayData?.data &&
              todayData.data.map((user, index) => (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{user.Name}</td>
                  <td>{user.Roll}</td>
                  <td>{user.Time}</td>
                </tr>
              ))}
          </tbody>
        </table>
        <br/>
        <Link to={'/'}>Back to Home</Link>
      </div>
    </div>
  );
};

export default TodayAttendance;
