import React, { useState, useEffect } from 'react';
import axios from 'axios';

function AttendanceList() {
  const [loading, setLoading] = useState(false);
  const [studentId, setStudentId] = useState('');
  const [attendanceRecorded, setAttendanceRecorded] = useState(false);

  // Activity counters
  const [clickCount, setClickCount] = useState(0);
  const [scrollCount, setScrollCount] = useState(0);
  const [mouseMoveCount, setMouseMoveCount] = useState(0);

  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    minHeight: '100vh',
    padding: '20px',
  };

  const headerStyle = {
    marginTop: '100px',
    marginBottom: '50px',
  };

  const buttonStyle = {
    margin: '15px',
    padding: '10px',
    backgroundColor: 'blue',
    color: 'white',
    cursor: 'pointer',
  };

  const inputStyle = {
    padding: '5px',
    marginRight: '5px',
  };

  const infoStyle = {
    marginTop: '10px',
    fontStyle: 'italic',
  };

  const apiUrl = 'http://localhost:7000';

  useEffect(() => {
    const handleActivity = (event) => {
      if (event.type === 'click') {
        setClickCount((prevCount) => prevCount + 1);
      } else if (event.type === 'scroll') {
        setScrollCount((prevCount) => prevCount + 1);
      } else if (event.type === 'mousemove') {
        setMouseMoveCount((prevCount) => prevCount + 1);
      }
    };

    window.addEventListener('click', handleActivity);
    window.addEventListener('scroll', handleActivity);
    window.addEventListener('mousemove', handleActivity);

    return () => {
      window.removeEventListener('click', handleActivity);
      window.removeEventListener('scroll', handleActivity);
      window.removeEventListener('mousemove', handleActivity);
    };
  }, []);

  const isAttendanceEnabled =
    clickCount >= 5 && scrollCount >= 5 && mouseMoveCount >= 5;

  const downloadExcel = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${apiUrl}/attendance`, {
        responseType: 'blob',
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'attendance.xlsx');
      document.body.appendChild(link);
      link.click();
    } catch (error) {
      console.error('Error downloading Excel file:', error);
    } finally {
      setLoading(false);
    }
  };

  const markAttendance = async () => {
    try {
      setLoading(true);
      await axios.post(`${apiUrl}/mark-attendance`, {
        student_id: studentId,
        clickCount,
        scrollCount,
        mouseMoveCount,
      });
      setAttendanceRecorded(true);
      setStudentId('');
    } catch (error) {
      console.error('Error marking attendance:', error);
      if (error.response && error.response.data.detail) {
        alert(`Error marking attendance: ${error.response.data.detail}`);
      } else {
        alert('Error marking attendance. Please check the server.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={containerStyle}>
      <h1 style={headerStyle}>Attendance List</h1>
      <button
        style={buttonStyle}
        onClick={downloadExcel}
        disabled={loading}
      >
        Download Excel
      </button>
      <div>
        <input
          style={inputStyle}
          type="text"
          placeholder="Enter Student ID"
          value={studentId}
          onChange={(e) => setStudentId(e.target.value)}
        />
        <button
          style={buttonStyle}
          onClick={markAttendance}
          disabled={loading || !isAttendanceEnabled || attendanceRecorded}
        >
          Mark Attendance
        </button>
      </div>
      {loading && <p>Loading...</p>}
      {attendanceRecorded && (
        <p style={infoStyle}>Attendance recorded successfully.</p>
      )}

      <p>Click Count: {clickCount}</p>
      <p>Scroll Count: {scrollCount}</p>
      <p>Mouse Move Count: {mouseMoveCount}</p>
    </div>
  );
}

export default AttendanceList;
