import React, { useState } from "react";
// import { db } from "../server/firebase";

function Register() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [userRole, setUserRole] = useState("");
  const [studentID, setStudentID] = useState("");


  const handleRegister = async () => {
    // e.preventDefault();
    // try {
    //   // const res = await db.auth().createUserWithEmailAndPassword(email, password, userRole);
    //   // console.log("register res: ", res)

    //   const userCredential = await db.auth().createUserWithEmailAndPassword(email, password);

    //   // Update user profile with additional information
    //   await userCredential.user.updateProfile({
    //     displayName: userRole, // Assign user role to displayName
    //   });

    //   // Update user document in Firestore (if you're using Firestore)
    //   await db.firestore().collection("users").doc(userCredential.user.uid).set({
    //     userRole,
    //     studentID,
    //   });

    //   console.log("register res: ", userCredential)

    // } catch (error) {
    //   console.error("Registration error:", error.message);
    // }
  };

  // useEffect(() => {
  //   getAllUserData()
  // }, []);

  // async function getAllUserData() {
  //   const usersCollection = db.firestore().collection("users");

  //   try {
  //     const querySnapshot = await usersCollection.get();

  //     const userData = [];
  //     querySnapshot.forEach((doc) => {
  //       userData.push({ id: doc.id, ...doc.data() });
  //     });

  //     return userData;
  //   } catch (error) {
  //     console.error("Error fetching user data:", error);
  //     return [];
  //   }
  // }

  return (
    <div className="login-page">
      <div className="form">
        <form className="register-form" onSubmit={handleRegister}>
          <input type="text" placeholder="Email address" value={email}
            onChange={(e) => setEmail(e.target.value)} />
          <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <input type="text" placeholder="User Role" value={userRole} onChange={(e) => setUserRole(e.target.value)} />
          <input type="text" placeholder="Profile ID" value={studentID} onChange={(e) => setStudentID(e.target.value)} />
          <button type="submit">Register</button>
          <p className="message">Already registered? <a href="/signin">Sign In</a></p>
        </form>
      </div>
    </div>
  );
}

export default Register;
