import React, { useState } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css"; // Import the calendar styles

const CalendarComponent = () => {
  const [date, setDate] = useState(new Date()); // Initialize the date state with the current date

  return (
    <div className="calendar-container">
      <h3>Calendar</h3>
      <Calendar value={date} onChange={setDate} />
    </div>
  );
};

export default CalendarComponent;
