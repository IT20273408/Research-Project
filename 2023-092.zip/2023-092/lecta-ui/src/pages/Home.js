import React from "react";
// import Footer from "./Footer"; // Import the Footer component

// const buttonStyle = {
//   backgroundColor: "blue",
//   color: "white",
//   border: "none",
//   padding: "5px 10px",
//   textDecoration: "none",
//   borderRadius: "5px",
//   marginRight: "10px", // Add right margin for button spacing
// };

// const headerStyle = {
//   width: "100%", // Set a larger width
//   backgroundColor: "#333", // White background
//   padding: "10px",
//   display: "flex",
//   justifyContent: "flex-end", // Right-align the content
// };

// const bannerStyle = {
//   width: "100%",
//   height: "auto",
//   zIndex: 0, // Banner is behind the buttons
// };

// const aboutUsStyle = {
//   backgroundColor: "#f9f9f9",
//   padding: "20px",
//   margin: "0 auto",
//   textAlign: "center",
//   paddingBottom: "5px",

// };

// const researchStyle = {
//   backgroundColor: "#f9f9f9",
//   padding: "20px",
//   margin: "0 auto",
//   textAlign: "center", 
// };

// const paragrapghs = {
//   padding: "15px",
// }
const MainScreen = () => {
  return (
    <div>
      <h1 style={{ display: "flex", justifyContent: "center" }}>
        Welcome to Lecta
      </h1>
      <a href="/meeting">Start Meeting</a>
      <br />
      <a href="/signin">Sign in</a>
      <br />
      <a href="/signup">Sign Up</a>
    </div>
  );
};

export default MainScreen;
