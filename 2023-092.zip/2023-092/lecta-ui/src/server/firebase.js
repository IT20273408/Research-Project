// import firebase from "firebase";
// import "firebase/auth";

// var firebaseConfig = {
//   apiKey: "AIzaSyBhZm0VEp7Jykrmma7jnzz4OrosBXJTpUQ",
//   authDomain: "research-sliit-9ba79.firebaseapp.com",
//   databaseURL: "https://research-sliit-9ba79-default-rtdb.firebaseio.com",
//   projectId: "research-sliit-9ba79",
//   storageBucket: "research-sliit-9ba79.appspot.com",
//   messagingSenderId: "940268068495",
//   appId: "1:940268068495:web:66e68c61a55b944941dafa"
// };
// // Initialize Firebase
// firebase.initializeApp(firebaseConfig);

// export const db = firebase;