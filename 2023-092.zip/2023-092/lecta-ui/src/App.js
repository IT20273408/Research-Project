import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Meeting from "./pages/meeting";
import Home from "./pages/Home";
import AddNewUser from "./pages/AddNewUser";
import TodayAttendance from "./pages/TodayAttendance";
import AttendanceList from "./pages/AttendanceList";
import SignIn from "./pages/SignIn";
import SignUp from "./pages/SignUp";

const App = () => {
  return (
    <div>
      <Router>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Home />} />
          <Route path="/meeting" element={<Meeting />} />
          <Route path="/add-new-user" element={<AddNewUser />} />
          <Route path="/today-attendance" element={<TodayAttendance />} />
          <Route path="/attendance-list" element={<AttendanceList />} />
          <Route path="/signin" element={<SignIn />} />
          <Route path="/signup" element={<SignUp />} />
        </Routes>
      </Router>
    </div>
  );
};

export default App;
