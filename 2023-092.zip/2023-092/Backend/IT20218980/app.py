from fastapi import FastAPI, Request
import pymongo
import certifi
from fastapi.middleware.cors import CORSMiddleware

import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.tag import pos_tag
from nltk.chunk import ne_chunk

# from nltk.parse import DependencyGraph
import spacy
from diagrams import Diagram, Cluster

app = FastAPI()
# Configure CORS
origins = ["*"]  # Replace with your frontend's URL
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Download NLTK data (if not already downloaded)
nltk.download("averaged_perceptron_tagger")
nltk.download("punkt")
nltk.download("maxent_ne_chunker")
nltk.download("words")
nltk.download("dependency_treebank")

nlp = spacy.load("en_core_web_sm")


def keyword_serializer(data):
    serialized_data = []

    for todo in data:
        serialized_data.append(
            {
                "id": str(todo["_id"]),
                "keywords": todo["keywords"],
                "imageTag": todo["imageTag"],
            }
        )
    return serialized_data


uri = "mongodb+srv://cuddlypetz:admin123@cluster0.maw3o4w.mongodb.net/?retryWrites=true&w=majority"
# Create a new client and connect to the server
client = pymongo.MongoClient(uri, ssl_ca_certs=certifi.where())

db = client["ResearchDB"]
collection = db["voice-keywords"]

# Send a ping to confirm a successful connection
try:
    client.admin.command("ping")
    print("Pinged your deployment. You successfully connected to MongoDB!")
except Exception as e:
    print(e)


@app.get("/getImageTags/{keyword}")
def get_ImageTags(keyword: str):
    try:
        json_data = keyword_serializer(collection.find({"keywords": keyword}))

        return json_data[0]["imageTag"]
    except Exception as e:
        return {"error": str(e)}


def Allkeyword_serializer(data):
    serialized_data = []

    for todo in data:
        serialized_data.append(todo["keywords"])

    return serialized_data


@app.get("/getAllKeywords/")
def get_AllKeywords():
    try:
        json_data = Allkeyword_serializer(collection.find({}, {"keywords": 1}))

        flat_data = [word for sublist in json_data for word in sublist]
        return flat_data
    except Exception as e:
        return {"error": str(e)}


@app.post("/sendcontext/")
async def get_voice(request: Request):
    data = await request.json()

    # Use this method to find the Keywords
    def find_keywords(keywords, sentence):
        found_keywords = []
        for keyword in keywords:
            if keyword.lower() in sentence.lower():
                found_keywords.append(keyword)
        return found_keywords

    # Tokenization
    sentences = sent_tokenize(data["voiceText"].lower())
    words = word_tokenize(sentences[0])  # Tokenize the first sentence
    keyword_array = get_AllKeywords()
    print(keyword_array)
    # Convert the arrays to sets
    set1 = set(keyword_array)
    set2 = set(words)

    # Find the intersection (matching words) between the sets
    matched_keywords = set1.intersection(set2)
    print(matched_keywords)

    pos_tags = pos_tag(words)

    # Named entity recognition
    named_entities = ne_chunk(pos_tags)
    filtered_words = [word for word, pos in pos_tags if pos in ["NN", "NNP"]]

    return {
        "message": "Lecture Voice Received",
        "Voice": data,
        "Keywords in the Text": matched_keywords,
        "Words": words,
        "Part-of-speech tags": pos_tags,
        "Named entities": named_entities,
        "Filtered Words": filtered_words,
    }