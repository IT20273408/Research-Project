from pymongo import MongoClient

client = MongoClient("mongodb+srv://cuddlypetz:admin123@cluster0.maw3o4w.mongodb.net/RearchDB?retryWrites=true&w=majority")
db = client.get_database("RearchDB")
collection = db.get_collection("voice-keywords")