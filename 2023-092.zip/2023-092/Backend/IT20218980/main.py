import pymongo
import certifi
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from bson import ObjectId
import json


# Custom JSON Encoder for handling ObjectId
class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, ObjectId):
            return str(obj)  # Convert ObjectId to a string
        return super().default(obj)

app = FastAPI(json_encoder=CustomJSONEncoder)

# Enable CORS
origins = ["*"]

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

uri = "mongodb+srv://cuddlypetz:admin123@cluster0.maw3o4w.mongodb.net/?retryWrites=true&w=majority"
# Create a new client and connect to the server
client = pymongo.MongoClient(uri, ssl_ca_certs=certifi.where())

db = client["ResearchDB"]
collection = db["voice-keywords"]

# Send a ping to confirm a successful connection
try:
    client.admin.command('ping')
    print("Pinged your deployment. You successfully connected to MongoDB!")
except Exception as e:
    print(e)

@app.get("/get_data")
async def get_data():
    data = []
    for document in collection.find({}):
        # Convert ObjectId to string before returning
        document["_id"] = str(document["_id"])
        data.append(document)
    return data