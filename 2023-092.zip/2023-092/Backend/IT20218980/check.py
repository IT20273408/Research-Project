from fastapi import FastAPI
import nltk
import certifi

app = FastAPI()

@app.get("/")
def read_root():
    # Download the 'punkt' resource on-the-fly if it's not already available
    nltk.download('punkt', download_dir='/tmp')
    
    # Example NLTK usage: Tokenize a sentence
    sentence = "This is an example sentence."
    words = nltk.word_tokenize(sentence)
    
    return {"message": "Hello, World", "tokenized_words": words}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
