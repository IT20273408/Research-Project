from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import tensorflow as tf
from fastapi.middleware.cors import CORSMiddleware
from typing import List
import pandas as pd

app = FastAPI()

# Load Dataset and tokenizer and model
dataset = pd.read_csv('./lecture_data_new.csv')
questions = dataset['Question'].values
tokenizer = tf.keras.preprocessing.text.Tokenizer()
tokenizer.fit_on_texts(questions)

# Enable CORS
origins = ["*"]

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create a data model for the POST request
class QuestionAnswer(BaseModel):
    question: str
    answer: str

local_model = tf.keras.models.load_model("./trained_model_best_02.h5")


# Sample function to process the question and answer
def process_question_answer(question: str, answer: str):
    new_student_question_seq = tokenizer.texts_to_sequences([question])
    new_student_answer_seq = tokenizer.texts_to_sequences([answer])
    max_seq_length = local_model.input_shape[0][1]
    new_student_question_seq = tf.keras.preprocessing.sequence.pad_sequences(
        new_student_question_seq, maxlen=max_seq_length
    )
    new_student_answer_seq = tf.keras.preprocessing.sequence.pad_sequences(
        new_student_answer_seq, maxlen=max_seq_length
    )
    predicted_mark = local_model.predict(
        [new_student_question_seq, new_student_answer_seq]
    )
    predicted_mark = predicted_mark.squeeze() * 10.0
    return predicted_mark

# Get Student Grade Based on Marks
def predict_student_grade(marks: int):
    if marks >= 7.5:
        return "Excelent"
    elif 7.5 > marks >= 6.5:
        return "Good"
    elif 6.5 > marks >= 4.5:
        return "Average"
    else: 
        return "Bellow Average"


# GET endpoint to check the health
@app.get("/health-check")
def get_items():
    return {"health": "OK!"}


# POST endpoint to predict student marks
@app.post("/predict-student-marks")
def predict_student_marks(question_answers: List[QuestionAnswer]):
    result = []
    for qa in question_answers:
        predicted_mark = process_question_answer(qa.question, qa.answer)
        rounded_mark = round(predicted_mark, 1)
        grade = predict_student_grade(rounded_mark)
        result.append({
            "question": qa.question,
            "answer": qa.answer,
            "mark": rounded_mark,
            "grade": grade
        })
    return {"status_code": 200, "data": result}


# In-memory data storage
questions_db = []


class Question(BaseModel):
    question_text: str


# POST endpoint to retrieve all items
@app.post("/add_questions")
async def add_questions(questions: list[Question]):
    global questions_db
    questions_db = []
    for question in questions:
        questions_db.append(question)
    return {"status_message": "Questions added successfully", "status_code": 200}


@app.get("/get_questions")
async def get_questions():
    return {"status_code": 200, "questions": questions_db}


# Run the FastAPI application with uvicorn
# You can run this script using: uvicorn filename:app --reload
# Replace "filename" with the name of your script.
