from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences

# Load and preprocess the data
dataset = pd.read_csv('./lecture_data_new.csv')
tokenizer = tf.keras.preprocessing.text.Tokenizer()
tokenizer.fit_on_texts(dataset['Question'].values)
max_seq_length = max(len(q) for q in tokenizer.texts_to_sequences(dataset['Question'].values))
answers_seq = tokenizer.texts_to_sequences(dataset['Answer'].values)

model = load_model('./trained_model.h5')

# Define the FastAPI app instance
app = FastAPI()

# Pydantic model for request validation
class StudentData(BaseModel):
    question: str
    answer: str

# Function to load the model as a dependency
def get_model():
    return model

# Prediction endpoint
@app.post("/predict/")
async def predict_mark(student_data: StudentData, model = Depends(get_model)):
    new_student_question_seq = tokenizer.texts_to_sequences([student_data.question])
    new_student_answer_seq = tokenizer.texts_to_sequences([student_data.answer])

    new_student_question_seq = pad_sequences(new_student_question_seq, maxlen=max_seq_length)
    new_student_answer_seq = pad_sequences(new_student_answer_seq, maxlen=max_seq_length)

    predicted_mark = model.predict([new_student_question_seq, new_student_answer_seq])
    predicted_mark = predicted_mark.squeeze() * 10.0

    return {"predicted_mark": float(predicted_mark)}

# Sample GET API endpoint
@app.get("/")
def read_root():
    return {"message": "Hello, this is a sample GET API!"}

class Item(BaseModel):
    name: str
    description: str | None = None
    price: float
    tax: float | None = None


app = FastAPI()


@app.post("/items/")
async def create_item(item: Item):
    return item
