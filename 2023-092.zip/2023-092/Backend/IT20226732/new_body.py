from fastapi import FastAPI, File, UploadFile
from starlette.responses import FileResponse
import cv2
import mediapipe as mp
import tensorflow as tf
import numpy as np

app = FastAPI()

# Initialize MediaPipe Pose
mp_pose = mp.solutions.pose
pose = mp_pose.Pose()

model = tf.keras.models.load_model('D:\\RP_Sample_Project\\Student-Engagment\\Backend\\models\\body-model.h5')

def process_image(image_path):
    frame = cv2.imread(image_path)

    input_size = (256, 256)  # Adjust to match your model's input size

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = pose.process(frame_rgb)

    if results.pose_landmarks:
        left_shoulder = results.pose_landmarks.landmark[mp_pose.PoseLandmark.LEFT_SHOULDER].y
        right_shoulder = results.pose_landmarks.landmark[mp_pose.PoseLandmark.RIGHT_SHOULDER].y

        if abs(left_shoulder - right_shoulder) < 0.05:
            label = "Correct Sitting"
            text_color = (0, 0, 255)  # Red
        else:
            label = "Wrong Sitting"
            text_color = (0, 255, 0)  # Green

        processed_frame = cv2.resize(frame, input_size)  # Resize the frame to (256, 256)
        processed_frame = processed_frame / 255.0  # Normalize pixel values (assuming your model expects values in [0, 1] range)
        processed_frame = tf.expand_dims(processed_frame, axis=0)

        sitting_prediction = model.predict(processed_frame)

        # Convert sitting_prediction to Python float
        sitting_prediction = float(sitting_prediction[0][0])

        # Calculate ankle lines
        left_ankle_x = int(results.pose_landmarks.landmark[mp_pose.PoseLandmark.LEFT_ANKLE].x * frame.shape[1])
        left_ankle_y = int(results.pose_landmarks.landmark[mp_pose.PoseLandmark.LEFT_ANKLE].y * frame.shape[0])
        right_ankle_x = int(results.pose_landmarks.landmark[mp_pose.PoseLandmark.RIGHT_ANKLE].x * frame.shape[1])
        right_ankle_y = int(results.pose_landmarks.landmark[mp_pose.PoseLandmark.RIGHT_ANKLE].y * frame.shape[0])

        # Draw ankle lines
        cv2.line(frame, (left_ankle_x, left_ankle_y), (right_ankle_x, right_ankle_y), (0, 255, 0), 2)

        result = {
            "label": label,
            "sitting_prediction": sitting_prediction
        }
        
        return frame, result

@app.post("/process_image/")
async def upload_image(file: UploadFile):
    # Save the uploaded image temporarily
    with open('./temp_image.jpg', 'wb') as image_file:
        image_file.write(file.file.read())
    
    # Process the image
    processed_frame, result = process_image('./temp_image.jpg')

    # Save the processed image temporarily
    cv2.imwrite('./temp_processed_image.jpg', processed_frame)

    # Return the processed image and result
    return {
        "result": result
    }

@app.get("/get_processed_image/")
async def get_processed_image():
    # Return the processed image
    return FileResponse('./temp_processed_image.jpg')
