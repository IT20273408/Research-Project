from locust import HttpUser, task, between

class FastAPILoadTest(HttpUser):
    wait_time = between(1, 3)  # Wait time between requests

    @task
    def analyze_image(self):
        headers = {"Content-Type": "multipart/form-data"}
        with open(r"C:\Users\DELL\Desktop\Project\High.jpg", "rb") as image_file:
            self.client.post("/detect", files={"file": image_file}, headers=headers)
