from fastapi import FastAPI, UploadFile, HTTPException, File
from fastapi.middleware.cors import CORSMiddleware
from enum import Enum
import cv2
import numpy as np
from tensorflow.keras.models import load_model
import os
from datetime import datetime

current_dir = os.path.dirname(os.path.abspath(__file__))
app = FastAPI()

# Handle CORS for frontend-backend communication
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust this if you know the exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class FaceExpressions(str, Enum):
    disgust = "Disgust"
    surprise = "Surprise"
    sad = "Sad"
    angry = "Angry"
    fear = "Fear"
    happy = "Happy"
    contempt = "Contempt"
    neutral = "Neutral"

class BodyPositions(str, Enum):
    correct_sitting = "Correct Sitting"
    wrong_sitting = "Wrong Sitting"

# Load the face model from the model directory
face_model_path = os.path.join(current_dir, 'models', 'face-model.h5')
face_model = load_model(face_model_path)

# Load the body model from the model directory
body_model_path = os.path.join(current_dir, 'models', 'body-model.h5')
body_model = load_model(body_model_path)

def preprocess_face_image(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    resized = cv2.resize(gray, (48, 48))
    normalized = resized / 255.0
    expanded = np.expand_dims(normalized, axis=0)
    expanded = np.expand_dims(expanded, axis=-1)  # Adding the channel dimension
    return expanded

def preprocess_body_image(img):
    resized = cv2.resize(img, (256, 256))
    normalized = resized / 255.0
    expanded = np.expand_dims(normalized, axis=0)
    return expanded

def calculate_engagement_score(face_expression, body_position):
    if body_position == BodyPositions.correct_sitting.value and face_expression == FaceExpressions.happy.value:
        return 10
    elif body_position == BodyPositions.correct_sitting.value and face_expression == FaceExpressions.sad.value:
        return 9
    elif body_position == BodyPositions.correct_sitting.value and face_expression == FaceExpressions.fear.value:
        return 8
    elif body_position == BodyPositions.correct_sitting.value and face_expression == FaceExpressions.neutral.value:
        return 8
    elif body_position == BodyPositions.correct_sitting.value and face_expression == FaceExpressions.angry.value:
        return 7
    elif body_position == BodyPositions.wrong_sitting.value and face_expression == FaceExpressions.happy.value:
        return 6
    elif body_position == BodyPositions.wrong_sitting.value and face_expression == FaceExpressions.sad.value:
        return 5
    elif body_position == BodyPositions.wrong_sitting.value and face_expression == FaceExpressions.neutral.value:
        return 4
    else:
        return 1

def engagement_level(engagement_score):
    if engagement_score > 7:
        return "Highly Engaged"
    elif 4 < engagement_score <= 7:
        return "Moderately Engaged"
    else:
        return "Low Engagement"

def detect_face_expression(img):
    processed_img = preprocess_face_image(img)
    prediction = face_model.predict(processed_img)
    predicted_index = np.argmax(prediction)
    labels = ["Disgust", "Surprise", "Sad", "Angry", "Fear", "Happy", "Contempt", "Neutral"]
    predicted_expression = labels[predicted_index]
    return predicted_expression

def detect_body_position(img):
    processed_img = preprocess_body_image(img)
    prediction = body_model.predict(processed_img)
    predicted_index = np.argmax(prediction)
    labels = ["Correct Sitting", "Wrong Sitting"]
    predicted_position = labels[predicted_index]
    return predicted_position

# Global variable to store the most recent engagement score and timestamp
latest_engagement_data = {
    "time": datetime.now().isoformat(),
    "engagement_score": 0  # default initial value
}

@app.post("/engagement")
async def get_or_send_engagement(file: UploadFile = File(...)):
    global latest_engagement_data
    try:
        contents = await file.read()
        nparr = np.frombuffer(contents, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        face_expression = detect_face_expression(img)
        body_position = detect_body_position(img)
        engagement_score = calculate_engagement_score(face_expression, body_position)
        level = engagement_level(engagement_score)
        
        # Update the global variable with the latest score and timestamp
        latest_engagement_data = {
            "time": datetime.now().isoformat(),
            "engagement_score": engagement_score
        }

        return {
            "face_expression": face_expression,
            "body_position": body_position,
            "engagement_score": engagement_score,
            "engagement_level": level
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
