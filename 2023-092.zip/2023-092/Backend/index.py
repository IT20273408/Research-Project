from fastapi import FastAPI, HTTPException, UploadFile, File, Request, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import cv2
import numpy as np
from tensorflow.keras.models import load_model
import os
from datetime import datetime, date
import tensorflow as tf
import pandas as pd
import uvicorn
from typing import List
from enum import Enum
import requests
from io import BytesIO
from tempfile import NamedTemporaryFile
import pymongo
import certifi
import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.tag import pos_tag
from nltk.chunk import ne_chunk
import spacy
from sklearn.neighbors import KNeighborsClassifier
import joblib
import base64
from openpyxl import Workbook, load_workbook

# Define your combined FastAPI app
current_dir = os.path.dirname(os.path.abspath(__file__))
app = FastAPI()

# Define the CORS middleware for the app (you can customize the origins)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health-check")
def get_items():
    return {"health": "OK!"}


# IT19063324
# Load Dataset and tokenizer and model
dataset = pd.read_csv("./IT19063324/lecture_data_new.csv")
questions = dataset["Question"].values
tokenizer = tf.keras.preprocessing.text.Tokenizer()
tokenizer.fit_on_texts(questions)


# Create a data model for the POST request
class QuestionAnswer(BaseModel):
    question: str
    answer: str


model_url = (
    "https://dr5xdp0d53dkl.cloudfront.net/sliit-research/trained_model_best_02.h5"
)

# Download the model from the URL
response = requests.get(model_url)

# Create a temporary file to store the model data
with NamedTemporaryFile(delete=False) as temp_file:
    temp_file.write(response.content)
    model_path = temp_file.name

# Load the model from the temporary file
local_model = tf.keras.models.load_model(model_path, compile=False)


# Sample function to process the question and answer
def process_question_answer(question: str, answer: str):
    new_student_question_seq = tokenizer.texts_to_sequences([question])
    new_student_answer_seq = tokenizer.texts_to_sequences([answer])
    max_seq_length = local_model.input_shape[0][1]
    new_student_question_seq = tf.keras.preprocessing.sequence.pad_sequences(
        new_student_question_seq, maxlen=max_seq_length
    )
    new_student_answer_seq = tf.keras.preprocessing.sequence.pad_sequences(
        new_student_answer_seq, maxlen=max_seq_length
    )
    predicted_mark = local_model.predict(
        [new_student_question_seq, new_student_answer_seq]
    )
    predicted_mark = predicted_mark.squeeze() * 10.0
    return predicted_mark


# Get Student Grade Based on Marks
def predict_student_grade(marks: int):
    if marks >= 7.5:
        return "Excelent"
    elif 7.5 > marks >= 6.5:
        return "Good"
    elif 6.5 > marks >= 4.5:
        return "Average"
    else:
        return "Bellow Average"


# POST endpoint to predict student marks
@app.post("/predict-student-marks")
def predict_student_marks(question_answers: List[QuestionAnswer]):
    result = []
    for qa in question_answers:
        predicted_mark = process_question_answer(qa.question, qa.answer)
        rounded_mark = round(predicted_mark, 1)
        grade = predict_student_grade(rounded_mark)
        result.append(
            {
                "question": qa.question,
                "answer": qa.answer,
                "mark": rounded_mark,
                "grade": grade,
            }
        )
    return {"status_code": 200, "data": result}


# In-memory data storage
questions_db = []


class Question(BaseModel):
    question_text: str


# POST endpoint to retrieve all items
@app.post("/add_questions")
async def add_questions(questions: list[Question]):
    global questions_db
    questions_db = []
    for question in questions:
        questions_db.append(question)
    return {"status_message": "Questions added successfully", "status_code": 200}


@app.get("/get_questions")
async def get_questions():
    return {"status_code": 200, "questions": questions_db}


# IT20226732
# Include the code and functionality from main.py here
class FaceExpressions(str, Enum):
    disgust = "Disgust"
    surprise = "Surprise"
    sad = "Sad"
    angry = "Angry"
    fear = "Fear"
    happy = "Happy"
    contempt = "Contempt"
    neutral = "Neutral"


class BodyPositions(str, Enum):
    correct_sitting = "Correct Sitting"
    wrong_sitting = "Wrong Sitting"


# Load the face model from the model directory
# face_model_url = "https://dr5xdp0d53dkl.cloudfront.net/sliit-research/face-model.h5"

# # Download the model from the URL
# face_model_response = requests.get(face_model_url)

# # Create a temporary file to store the model data
# with NamedTemporaryFile(delete=False) as temp_file:
#     temp_file.write(face_model_response.content)
#     face_model_path = temp_file.name

# # Load the model from the temporary file
# face_model = tf.keras.models.load_model(face_model_path, compile=False)

face_model_path = os.path.join(current_dir, "models", "face-model.h5")
face_model = load_model(face_model_path)

# Load the body model from the model directory
# body_model_url = "https://dr5xdp0d53dkl.cloudfront.net/sliit-research/body-model.h5"

# # Download the model from the URL
# body_model_response = requests.get(body_model_url)

# # Create a temporary file to store the model data
# with NamedTemporaryFile(delete=False) as temp_file:
#     temp_file.write(body_model_response.content)
#     body_model_path = temp_file.name

# # Load the model from the temporary file
# body_model = tf.keras.models.load_model(body_model_path, compile=False)

body_model_path = os.path.join(current_dir, "models", "body-model.h5")
body_model = load_model(body_model_path)


def preprocess_face_image(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    resized = cv2.resize(gray, (48, 48))
    normalized = resized / 255.0
    expanded = np.expand_dims(normalized, axis=0)
    expanded = np.expand_dims(expanded, axis=-1)  # Adding the channel dimension
    return expanded


def preprocess_body_image(img):
    resized = cv2.resize(img, (256, 256))
    normalized = resized / 255.0
    expanded = np.expand_dims(normalized, axis=0)
    return expanded


def calculate_engagement_score(face_expression, body_position):
    if (
        body_position == BodyPositions.correct_sitting.value
        and face_expression == FaceExpressions.happy.value
    ):
        return 10
    elif (
        body_position == BodyPositions.correct_sitting.value
        and face_expression == FaceExpressions.sad.value
    ):
        return 9
    elif (
        body_position == BodyPositions.correct_sitting.value
        and face_expression == FaceExpressions.fear.value
    ):
        return 8
    elif (
        body_position == BodyPositions.correct_sitting.value
        and face_expression == FaceExpressions.neutral.value
    ):
        return 8
    elif (
        body_position == BodyPositions.correct_sitting.value
        and face_expression == FaceExpressions.angry.value
    ):
        return 7
    elif (
        body_position == BodyPositions.wrong_sitting.value
        and face_expression == FaceExpressions.happy.value
    ):
        return 6
    elif (
        body_position == BodyPositions.wrong_sitting.value
        and face_expression == FaceExpressions.sad.value
    ):
        return 5
    elif (
        body_position == BodyPositions.wrong_sitting.value
        and face_expression == FaceExpressions.neutral.value
    ):
        return 4
    else:
        return 1


def engagement_level(engagement_score):
    if engagement_score > 7:
        return "Highly Engaged"
    elif 4 < engagement_score <= 7:
        return "Moderately Engaged"
    else:
        return "Low Engagement"


def detect_face_expression(img):
    processed_img = preprocess_face_image(img)
    prediction = face_model.predict(processed_img)
    predicted_index = np.argmax(prediction)
    labels = [
        "Disgust",
        "Surprise",
        "Sad",
        "Angry",
        "Fear",
        "Happy",
        "Contempt",
        "Neutral",
    ]
    predicted_expression = labels[predicted_index]
    return predicted_expression


def detect_body_position(img):
    processed_img = preprocess_body_image(img)
    prediction = body_model.predict(processed_img)
    predicted_index = np.argmax(prediction)
    labels = ["Correct Sitting", "Wrong Sitting"]
    predicted_position = labels[predicted_index]
    return predicted_position


# Global variable to store the most recent engagement score and timestamp
latest_engagement_data = {
    "time": datetime.now().isoformat(),
    "engagement_score": 0,  # default initial value
}


@app.post("/detect")
async def detect(file: UploadFile = File(...)):
    global latest_engagement_data
    try:
        contents = await file.read()
        nparr = np.frombuffer(contents, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        face_expression = detect_face_expression(img)
        body_position = detect_body_position(img)
        engagement_score = calculate_engagement_score(face_expression, body_position)
        level = engagement_level(engagement_score)

        # Update the global variable with the latest score and timestamp
        latest_engagement_data = {
            "time": datetime.now().isoformat(),
            "engagement_score": engagement_score,
        }

        return {
            "time": datetime.now().isoformat(),
            "face_expression": face_expression,
            "body_position": body_position,
            "engagement_score": engagement_score,
            "engagement_level": level,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/engagement")
async def get_engagement():
    return latest_engagement_data


# IT20218980
# Download NLTK data (if not already downloaded)
nltk.download("averaged_perceptron_tagger")
nltk.download("punkt")
nltk.download("maxent_ne_chunker")
nltk.download("words")
nltk.download("dependency_treebank")

nlp = spacy.load("en_core_web_sm")


def keyword_serializer(data):
    serialized_data = []

    for todo in data:
        serialized_data.append(
            {
                "id": str(todo["_id"]),
                "keywords": todo["keywords"],
                "imageTag": todo["imageTag"],
            }
        )
    return serialized_data


uri = "mongodb+srv://cuddlypetz:admin123@cluster0.maw3o4w.mongodb.net/?retryWrites=true&w=majority"
# Create a new client and connect to the server
client = pymongo.MongoClient(uri, ssl_ca_certs=certifi.where())

db = client["ResearchDB"]
collection = db["voice-keywords"]

# Send a ping to confirm a successful connection
try:
    client.admin.command("ping")
    print("Pinged your deployment. You successfully connected to MongoDB!")
except Exception as e:
    print(e)


@app.get("/getImageTags/{keyword}")
def get_ImageTags(keyword: str):
    try:
        json_data = keyword_serializer(collection.find({"keywords": keyword}))

        return json_data[0]["imageTag"]
    except Exception as e:
        return {"error": str(e)}


def Allkeyword_serializer(data):
    serialized_data = []

    for todo in data:
        serialized_data.append(todo["keywords"])

    return serialized_data


@app.get("/getAllKeywords/")
def get_AllKeywords():
    try:
        json_data = Allkeyword_serializer(collection.find({}, {"keywords": 1}))

        flat_data = [word for sublist in json_data for word in sublist]
        return flat_data
    except Exception as e:
        return {"error": str(e)}


class VoiceInput(BaseModel):
    voiceText: str


def process_text(text):
    sentences = sent_tokenize(text.lower())
    words = word_tokenize(sentences[0])
    keyword_array = get_AllKeywords()  # Define get_AllKeywords() elsewhere
    set1 = set(keyword_array)
    set2 = set(words)
    matched_keywords = set1.intersection(set2)
    pos_tags = pos_tag(words)
    named_entities = ne_chunk(pos_tags)
    filtered_words = [word for word, pos in pos_tags if pos in ["NN", "NNP"]]
    return {
        "Keywords in the Text": matched_keywords,
        "Words": words,
        "Part-of-speech tags": pos_tags,
        "Named entities": named_entities,
        "Filtered Words": filtered_words,
    }


@app.post("/sendcontext/")
async def get_voice(request: Request, voice_data: VoiceInput):
    result = process_text(voice_data.voiceText)
    return {
        "message": "Lecture Voice Received",
        "Voice": voice_data,
        **result,
    }


# IT20273408
# Create the static directory if it doesn't exist
if not os.path.exists("static"):
    os.makedirs("static")

# Serve static files (React build)
app.mount("/static", StaticFiles(directory="utils/static"), name="static")

# Initialize VideoCapture object to access Webcam
face_detector = cv2.CascadeClassifier(
    cv2.data.haarcascades + "utils/haarcascade_frontalface_default.xml"
)


# Define Pydantic model for user data
class NewUserData(BaseModel):
    image: str
    images: List[str]
    newusername: str
    newuserid: int


# If these directories don't exist, create them
if not os.path.isdir("utils/static/faces"):
    os.makedirs("utils/static/faces")

if "face_recognition_model.pkl" not in os.listdir("utils/static"):
    with open("utils/static/face_recognition_model.pkl", "wb") as f:
        # Placeholder for creating the initial model file
        pass


# Extract the face from an image
def extract_faces(img):
    try:
        if img is not None and not img.size == 0:  # Check if the image is not empty
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            face_points = face_detector.detectMultiScale(gray, 1.3, 5)
            return face_points
        else:
            return []
    except:
        return []


# Identify face using ML model
def identify_face(facearray):
    model = joblib.load("utils/static/face_recognition_model.pkl")

    # Ensure that facearray is a 2D or 3D array (e.g., for grayscale or color images)
    if len(facearray.shape) == 3:
        # Convert the color image to grayscale
        facearray = cv2.cvtColor(facearray, cv2.COLOR_BGR2GRAY)

    # Flatten the 2D or 3D array into a 1D array
    facearray = facearray.reshape(-1)

    return model.predict([facearray])
    # return facearray  # Wrap facearray in a list


# A function which trains the model on all the faces available in the faces folder
def train_model():
    faces = []
    labels = []
    userlist = os.listdir("utils/static/faces")
    for user in userlist:
        for imgname in os.listdir(f"utils/static/faces/{user}"):
            img = cv2.imread(f"utils/static/faces/{user}/{imgname}")
            if img is not None and not img.size == 0:  # Check if the image is not empty
                resized_face = cv2.resize(img, (50, 50))
                faces.append(resized_face.ravel())
                labels.append(user)
    faces = np.array(faces)
    knn = KNeighborsClassifier(n_neighbors=5)
    knn.fit(faces, labels)
    joblib.dump(knn, "utils/static/face_recognition_model.pkl")


# Initialize the attendance CSV file
attendance_file_path = (
    f'utils/Attendance/Attendance-{date.today().strftime("%m_%d_%y")}.csv'
)
if not os.path.isfile(attendance_file_path):
    with open(attendance_file_path, "w") as f:
        f.write("Name,Roll,Time\n")


# Extract info from today's attendance file in the attendance folder
def extract_attendance():
    df = pd.read_csv(attendance_file_path)
    names = df["Name"]
    rolls = df["Roll"]
    times = df["Time"]
    l = len(df)
    return names, rolls, times, l


# Add Attendance of a specific user
def add_attendance(name):
    username = name.split("_")[0]
    userid = name.split("_")[1]
    current_time = datetime.now().strftime("%H:%M:%S")

    df = pd.read_csv(attendance_file_path)
    if int(userid) not in list(df["Roll"]):
        with open(attendance_file_path, "a") as f:
            f.write(f"\n{username},{userid},{current_time}")


@app.post("/add")
async def add(new_user_data: NewUserData):
    newusername = new_user_data.newusername
    newuserid = new_user_data.newuserid
    image = new_user_data.image
    images = new_user_data.images

    hasFaces = 0
    userimagefolder = f"utils/static/faces/{newusername}_{newuserid}"
    if not os.path.isdir(userimagefolder):
        os.makedirs(userimagefolder)

    for i, base64_data in enumerate(images):
        # Remove the 'data:image/png;base64,' prefix if it's included
        if base64_data.startswith("data:image"):
            base64_data = base64_data.split(",")[1]

        image_data = base64.b64decode(base64_data)
        np_array = np.frombuffer(image_data, np.uint8)
        frame = cv2.imdecode(np_array, cv2.IMREAD_UNCHANGED)

        faces = extract_faces(frame)
        if len(faces) > 0:  # Check if faces is not empty
            hasFaces = 1
            for x, y, w, h in faces:
                face = frame[y : y + h, x : x + w]
                cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 20), 2)
                name = newusername + "_" + str(i) + ".jpg"
                cv2.imwrite(userimagefolder + "/" + name, frame[y : y + h, x : x + w])

    if hasFaces == 1:
        mzg = "User added successfully"
        status = "true"

    else:
        mzg = "Sorry, can't identify face. Please try again."
        status = "false"

    train_model()

    # Return a success message (adjust as needed)
    return {"success": status, "message": mzg}


def process_image(image_data):
    try:
        if image_data.startswith("data:image"):
            image_data = image_data.split(",")[1]

        image_bytes = base64.b64decode(image_data)
        np_array = np.frombuffer(image_bytes, np.uint8)
        frame = cv2.imdecode(np_array, cv2.IMREAD_UNCHANGED)

        faces = extract_faces(frame)
        if len(faces) > 0:
            for x, y, w, h in faces:
                face = frame[y : y + h, x : x + w]
                cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 20), 2)
                face = cv2.resize(frame[y : y + h, x : x + w], (50, 50))

                identified_person = identify_face(face.reshape(1, -1))[0]
            add_attendance(identified_person)
            username = identified_person.split("_")[0]

            return {
                "success": True,
                "message": f"Welcome {username}! Your attendance was taken successfully",
            }
        else:
            return {
                "success": False,
                "message": "Sorry, can't identify faces. Please try again.",
            }
    except Exception as e:
        return {
            "success": False,
            "message": "An error occurred while processing the image.",
            "error": str(e),
        }


@app.post("/markAttendance")
async def mark_attendance(image: UploadFile = Form(...)):
    result = process_image(image)
    return result


@app.get("/total")
async def total():
    userlist = os.listdir("utils/static/faces")
    names = []
    rolls = []
    l = len(userlist)

    for i in userlist:
        name, roll = i.split("_")
        names.append(name)
        rolls.append(roll)

    return {"data": {"names": names, "ids": rolls}, "total": l}


@app.get("/todayAttendance")
async def todayAttendance():
    if os.path.isfile(attendance_file_path):
        df = pd.read_csv(attendance_file_path)
        data = df.to_dict(orient="records")
    else:
        data = []

    return {"data": data}


class Student(BaseModel):
    student_id: str
    clickCount: int
    scrollCount: int
    mouseMoveCount: int


def mark_attendance(student_id, clickCount, scrollCount, mouseMoveCount):
    try:
        workbook = load_workbook("attendance.xlsx")
        sheet = workbook.active
    except:
        workbook = Workbook()
        sheet = workbook.active
        sheet.append(
            [
                "Student ID",
                "Attendance Time",
                "Click Count",
                "Scroll Count",
                "MouseMove Count",
            ]
        )

    now = datetime.datetime.now()
    attendance_time = now.strftime("%Y-%m-%d %H:%M:%S")

    sheet.append([student_id, attendance_time, clickCount, scrollCount, mouseMoveCount])

    workbook.save("attendance.xlsx")


@app.post("/mark-attendance")
async def post_mark_attendance(student: Student):
    if not student.student_id:
        raise HTTPException(status_code=422, detail="Student ID is required")

    mark_attendance(
        student.student_id,
        student.clickCount,
        student.scrollCount,
        student.mouseMoveCount,
    )

    return {"message": "Attendance marked successfully."}


@app.get("/attendance")
async def get_attendance():
    try:
        workbook = load_workbook("attendance.xlsx")
        sheet = workbook.active
        data = []

        for row in sheet.iter_rows(min_row=2, values_only=True):
            student_id, attendance_time, clickCount, scrollCount, mouseMoveCount = row
            data.append(
                {
                    "student_id": student_id,
                    "attendance_time": attendance_time,
                    "clickCount": clickCount,
                    "scrollCount": scrollCount,
                    "mouseMoveCount": mouseMoveCount,
                }
            )

        return data
    except Exception as e:
        print("Error loading attendance data:", str(e))
        raise HTTPException(
            status_code=500, detail="Failed to retrieve attendance data"
        )


@app.get("/download-attendance")
async def download_attendance():
    try:
        return FileResponse("attendance.xlsx", filename="attendance.xlsx")
    except Exception as e:
        print("Error downloading attendance data:", str(e))
        raise HTTPException(
            status_code=500, detail="Failed to download attendance data"
        )


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)

# Run : source Backend/IT19063324/myenv/bin/activate
# Run the FastAPI application with uvicorn
# You can run this script using: uvicorn index:app --reload
# Replace "filename" with the name of your script.
