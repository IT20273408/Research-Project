from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from openpyxl import Workbook, load_workbook
import datetime
from pydantic import BaseModel

app = FastAPI()

origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Student(BaseModel):
    student_id: str
    clickCount: int
    scrollCount: int
    mouseMoveCount: int

def mark_attendance(student_id, clickCount, scrollCount, mouseMoveCount):
    try:
        workbook = load_workbook("attendance.xlsx")
        sheet = workbook.active
    except:
        workbook = Workbook()
        sheet = workbook.active
        sheet.append(["Student ID", "Attendance Time", "Click Count", "Scroll Count", "MouseMove Count"])

    now = datetime.datetime.now()
    attendance_time = now.strftime("%Y-%m-%d %H:%M:%S")

    sheet.append([student_id, attendance_time, clickCount, scrollCount, mouseMoveCount])

    workbook.save("attendance.xlsx")

@app.post("/mark-attendance")
async def post_mark_attendance(student: Student):
    if not student.student_id:
        raise HTTPException(status_code=422, detail="Student ID is required")
    
    mark_attendance(student.student_id, student.clickCount, student.scrollCount, student.mouseMoveCount)
    
    return {"message": "Attendance marked successfully."}

@app.get("/attendance")
async def get_attendance():
    try:
        workbook = load_workbook("attendance.xlsx")
        sheet = workbook.active
        data = []

        for row in sheet.iter_rows(min_row=2, values_only=True):
            student_id, attendance_time, clickCount, scrollCount, mouseMoveCount = row
            data.append({
                "student_id": student_id,
                "attendance_time": attendance_time,
                "clickCount": clickCount,
                "scrollCount": scrollCount,
                "mouseMoveCount": mouseMoveCount,
            })

        return data
    except Exception as e:
        print("Error loading attendance data:", str(e))
        raise HTTPException(status_code=500, detail="Failed to retrieve attendance data")

@app.get("/download-attendance")
async def download_attendance():
    try:
        return FileResponse("attendance.xlsx", filename="attendance.xlsx")
    except Exception as e:
        print("Error downloading attendance data:", str(e))
        raise HTTPException(status_code=500, detail="Failed to download attendance data")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=7000)
