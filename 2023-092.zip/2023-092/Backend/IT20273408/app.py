from fastapi import FastAPI, HTTPException, Form, UploadFile, File
from fastapi.staticfiles import StaticFiles
#from fastapi.responses import HTMLResponse
from pydantic import BaseModel
import os
import cv2
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
import joblib
from datetime import datetime, date
import pandas as pd
from fastapi.middleware.cors import CORSMiddleware
import io
import base64
from typing import List
app = FastAPI()

# Enable CORS
origins = ["*"]

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create the static directory if it doesn't exist
if not os.path.exists('static'):
    os.makedirs('static')

# Serve static files (React build)
app.mount("/static", StaticFiles(directory="static"), name="static")

# Initialize VideoCapture object to access Webcam
face_detector = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Define Pydantic model for user data
class NewUserData(BaseModel):
    image: str
    images: List[str]
    newusername: str
    newuserid: int

# If these directories don't exist, create them
if not os.path.isdir('static/faces'):
    os.makedirs('static/faces')

if 'face_recognition_model.pkl' not in os.listdir('static'):
    with open('static/face_recognition_model.pkl', 'wb') as f:
        # Placeholder for creating the initial model file
        pass

# Extract the face from an image
def extract_faces(img):
    try:
        if img is not None and not img.size == 0:  # Check if the image is not empty
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            face_points = face_detector.detectMultiScale(gray, 1.3, 5)
            return face_points
        else:
            return []
    except:
        return []

# Identify face using ML model
def identify_face(facearray):
    model = joblib.load('static/face_recognition_model.pkl')
    
    # Ensure that facearray is a 2D or 3D array (e.g., for grayscale or color images)
    if len(facearray.shape) == 3:
        # Convert the color image to grayscale
        facearray = cv2.cvtColor(facearray, cv2.COLOR_BGR2GRAY)
    
    # Flatten the 2D or 3D array into a 1D array
    facearray = facearray.reshape(-1)
    
    return model.predict([facearray])
    #return facearray  # Wrap facearray in a list

# A function which trains the model on all the faces available in the faces folder
def train_model():
    faces = []
    labels = []
    userlist = os.listdir('static/faces')
    for user in userlist:
        for imgname in os.listdir(f'static/faces/{user}'):
            img = cv2.imread(f'static/faces/{user}/{imgname}')
            if img is not None and not img.size == 0:  # Check if the image is not empty
                resized_face = cv2.resize(img, (50, 50))
                faces.append(resized_face.ravel())
                labels.append(user)
    faces = np.array(faces)
    knn = KNeighborsClassifier(n_neighbors=5)
    knn.fit(faces, labels)
    joblib.dump(knn, 'static/face_recognition_model.pkl')

# Initialize the attendance CSV file
attendance_file_path = f'Attendance/Attendance-{date.today().strftime("%m_%d_%y")}.csv'
if not os.path.isfile(attendance_file_path):
    with open(attendance_file_path, 'w') as f:
        f.write('Name,Roll,Time\n')

# Extract info from today's attendance file in the attendance folder
def extract_attendance():
    df = pd.read_csv(attendance_file_path)
    names = df['Name']
    rolls = df['Roll']
    times = df['Time']
    l = len(df)
    return names, rolls, times, l

# Add Attendance of a specific user
def add_attendance(name):

    username = name.split('_')[0]
    userid = name.split('_')[1]
    current_time = datetime.now().strftime("%H:%M:%S")
    
    df = pd.read_csv(attendance_file_path)
    if int(userid) not in list(df['Roll']):
        with open(attendance_file_path, 'a') as f:
            f.write(f'\n{username},{userid},{current_time}')

# FastAPI routes
@app.get("/")
async def read_root():
    return {"message": "Welcome to the FastAPI backend!"}

@app.post("/add")
async def add(
    new_user_data: NewUserData
):
    newusername = new_user_data.newusername
    newuserid = new_user_data.newuserid
    image = new_user_data.image
    images = new_user_data.images

    hasFaces = 0
    userimagefolder = f'static/faces/{newusername}_{newuserid}'
    if not os.path.isdir(userimagefolder):
        os.makedirs(userimagefolder)

    for i, base64_data in enumerate(images):
        # Remove the 'data:image/png;base64,' prefix if it's included
        if base64_data.startswith("data:image"):
            base64_data = base64_data.split(",")[1]
        
        image_data = base64.b64decode(base64_data)
        np_array = np.frombuffer(image_data, np.uint8)
        frame = cv2.imdecode(np_array, cv2.IMREAD_UNCHANGED)

        faces = extract_faces(frame)
        if len(faces) > 0:  # Check if faces is not empty
            hasFaces = 1
            for (x, y, w, h) in faces:
                face = frame[y:y+h, x:x+w]
                cv2.rectangle(frame,(x, y), (x+w, y+h), (255, 0, 20), 2)
                name = newusername+'_'+str(i)+'.jpg'
                cv2.imwrite(userimagefolder+'/'+name,frame[y:y+h,x:x+w])

    if hasFaces == 1:

        mzg = "User added successfully"
        status = "true"

    else:
        mzg = "Sorry, can't identify face. Please try again."
        status = "false"

    train_model()

    # Return a success message (adjust as needed)
    return {"success" : status, "message": mzg}


@app.post("/markAttendance")
async def markAttendance(
    image: str = Form(...)
):

    if image.startswith("data:image"):
        image = image.split(",")[1]

    image_data = base64.b64decode(image)
    np_array = np.frombuffer(image_data, np.uint8)
    frame = cv2.imdecode(np_array, cv2.IMREAD_UNCHANGED)

    faces = extract_faces(frame)
    if len(faces) > 0:  # Check if faces is not empty
        for (x, y, w, h) in faces:

            face = frame[y:y+h, x:x+w]
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 20), 2)
            face = cv2.resize(frame[y:y+h, x:x+w], (50, 50))
            
            identified_person = identify_face(face.reshape(1, -1))[0]
        add_attendance(identified_person)
        username = identified_person.split('_')[0]

        return {"success" : "true",  "message": "Welcome " + username + "!, Your attendance was taken successfully"}
        
    else:
        return {"success" : "false", "message": "Sorry, can't identify faces. Please try again."}

@app.get("/total")
async def total():

    userlist = os.listdir('static/faces')
    names = []
    rolls = []
    l = len(userlist)

    for i in userlist:
        name,roll = i.split('_')
        names.append(name)
        rolls.append(roll)

    return {"data": { "names" : names , "ids" : rolls }, "total" : l}
 
@app.get("/todayAttendance")
async def todayAttendance():
    if os.path.isfile(attendance_file_path):
        df = pd.read_csv(attendance_file_path)
        data = df.to_dict(orient='records')
    else:
        data = []

    return {"data": data }

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="localhost", port=8000)
