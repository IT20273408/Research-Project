# 2023-092

# Topic - Modern application for classrooms using AI & ML
## Research group the project belongs to - Machine Learning and Soft Computing (MLSC)
## Research area the project belongs to - E-learning and Education (ELE)
## Main Objective - Using advanced technology such as machine learning algorithms, paper correcting, facial recognition, and speech-to-image generation to improve various aspects of the educational experience, including student engagement, attendance management, and lectures productivity.
## Main Research questions - 
* What is E-Learning?
* Who faces more problems in online learning?
* What are the problems lectures faces?

## Individual research question
* ### IT19063324 - Theebanraj U.
  * What is Natural Language Processing?
  * How can we resuce lectures' paper correction time? and How we can overcomes it?
  * How can we automate paper correction?
* ### IT20226732 - Kanishkar R.
  * Student Engagement in Online Lectures
  * What is Facial Recognition & Posture detection?
  * What is CNN & PoseNet?
* ### IT20218980 - Gunathilake C.D
  * How can we overcome unclear diagram drawing during lectures?
  * How can we reduce the time we spend on the diagram drawing?
  * How can we use lecture’s voice to generate real time diagrams?
  * What is Object Mapping?
* ### IT20273408 - Hennayake H.M.G.J
  * How can smart attendance marking using face recognition and heatmap(clicks, scroll, mouse movements) in Online lectures?
  * What are face recognition and heatmap?
  * What are the potential challenges and benefits of using smart attendance marking with face recognition and activity monitoring to measure student activeness?
<br/>
<hr>

## Supervisor Details
* Supervisor - Dr. Jeewanee Bamunusinghe
* Co-Supervisor - Ms. Supipi Karunathilaka

# Members Details

| Member Name | Student ID | Specialization | individual Components |
| :---: | :---: | :---: | :---: |
| Theebanraj U. | IT19063324 | Software Engineering | A Machine Learning Approach to Improving essay type Answer correcting accuracy through Automated Correction.
| Kanishkar R. | IT20226732 | Software Engineering | Enhance the Student Engagement in Classroom Using Facial Recognition and Posture Detection Analysis.
| Gunathilake C.D | IT20218980 | Software Engineering | Enhance the Teachers whiteboard writing during the lectures by using speech to image generating.
| Hennayake H.M.G.J | IT20273408 | Software Engineering | Smart Attendance Management System Based on Face Recognition Technique.

